from django.db import models
class aprendiz(models.Model):
    documento = models.CharField(15,unique =True)
    nombre = models.CharField(max_length=15)
    apellido = models.CharField(max_length=15)
    email = models.EmailField(unique =True)
    def __str__(self):
        return f"{self.nombre} {self.apellido}"
    
class carnet(models.Model):
    rol = models.CharField(max_length=15)
    nombre = models.CharField(max_length=15)
    apellido = models.CharField(max_length=15)
    tipo_documento = models.CharField(max_length=20)
    documento = models.CharField(12,unique =True)
    rh = models.CharField(max_length=3)
    nombre_centro = models.CharField(max_length=40)
    departamento = models.CharField(max_length=15)
    programa = models.CharField(max_length=100)
    grupo = models.CharField(max_length=9)
    def __str__(self):
        return f"{self.nombre} {self.apellido} {self.documento} {self.grupo}"


class instructor(models.Model):
    carrera = models.CharField(max_length=15)
    documento = models.CharField(15,unique =True)
    nombre = models.CharField(max_length=15)
    apellido = models.CharField(max_length=15)
    email = models.EmailField(unique =True)
    def __str__(self):
        return f"{self.nombre} {self.apellido}"